# Program to Create and Access Nested Tuples:

nested_tuple = (1, (2, 3), 4)
print(nested_tuple[1][0]) # Outputs: 2
print("66.This code is written by Raghavv Gupta ERP- 0221BCA032")