#WAP to create a default function 
def greet(name="guest"):
    print(f"Hello,{name}!")
greet()
greet("Raghavv")
print("72.This code is written by Raghavv Gupta ERP- 0221BCA032")