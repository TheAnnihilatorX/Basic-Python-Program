# Program to Use Iterators in a Loop:

my_list = [1, 2, 3, 4]
it = iter(my_list)
for item in it:
 print(item) # Outputs: 1, 2, 3, 4
print("52.This code is written by Raghavv Gupta ERP-0221BCA032")