#proper indentation in a function
def my_function():
    print("this function is properly intended")
    if True:
        print("this is inside an if statement")
# properly indented function
def my_other_function():
    print("this will not cause an error") #properly intended
#properly indented in a loop
for i in range(5):
    print(i) #properly indented inside the loop
#call the function to see the output
my_function()
my_other_function()
print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")