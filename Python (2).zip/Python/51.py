# Program to Use Built-in Iterators:

my_list = [1, 2, 3, 4]
it = iter(my_list)
print(next(it)) # Outputs: 1
print(next(it)) # Outputs: 2
print("51.This code is written by Raghavv Gupta ERP- 0221BCA032")