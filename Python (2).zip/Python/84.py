#Wap to using a module

import math_utils # type: ignore
result = math_utils.add(5, 3)
print(result)