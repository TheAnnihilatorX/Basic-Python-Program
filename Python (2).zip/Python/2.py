variable = 10
_variable = "underscore"
var123 = 3.14
print(variable)
print(_variable)
print(var123)

print("2.THIS PROGRAM IS WRITTEN BY Raghavv Gupta ERP :- 0221BCA032")