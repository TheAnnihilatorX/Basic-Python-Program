# Program to Use Set Comprehension:

squares = {x**2 for x in range(5)}
print(squares) # Outputs: {0, 1, 4, 9, 16}
print("57.This code is written by Raghavv Gupta ERP- 0221BCA032")