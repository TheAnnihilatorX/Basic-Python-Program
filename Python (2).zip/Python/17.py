a = True
b = True

#AND Operator
print(f"{a} and {b} : {a and b}")

#OR Operator
print(f"{a} or {b} : {a or b}")

#NOT Operators
print(f"not {a} :  {not a}")
print(f"not {b} :  {not b}")
print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")