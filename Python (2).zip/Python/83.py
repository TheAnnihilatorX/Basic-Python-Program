# WAP to  demonstrate Math Utils

def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

print("83. This code is written by Raghavv Gupta ERP- 0221BCA032")
