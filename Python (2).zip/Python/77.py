# Write a Python program to demonstrate No explicit return

def greet(name):
    print(f"Hello,{name}")
result = greet("Raghavv")
print(result)
print("77.This code is written by Raghavv Gupta ERP- 0221BCA032")