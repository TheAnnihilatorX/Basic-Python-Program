# Program to Use range() with Negative Step:

for i in range(10, 0, -2):
 print(i) # Outputs: 10, 8, 6, 4, 2
print("64.This code is written by Raghavv Gupta ERP- 0221BCA032")