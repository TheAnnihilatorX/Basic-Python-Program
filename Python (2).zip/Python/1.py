print("Hello World")
print("1.THIS PROGRAM IS WRITTEN BY Raghavv Gupta ERP :- 0221BCA032")