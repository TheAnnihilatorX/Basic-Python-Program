# Program to Use range() with Step:

for i in range(1, 10, 2):
 print(i) # Outputs: 1, 3, 5, 7, 9
print("61.This code is written by Raghavv Gupta ERP- 0221BCA032")