# Program to Iterate Through Dictionary Items:

my_dict = {'a': 1, 'b': 2, 'c': 3}
for key, value in my_dict.items():
    print(f"{key}: {value}")
print("70.This code is written by Raghavv Gupta ERP- 0221BCA032")