# Program to Use range() for Iteration:

for i in range(5):
 print(i) # Outputs: 0, 1, 2, 3, 4
print("62.This code is written by Raghavv Gupta ERP- 0221BCA032")