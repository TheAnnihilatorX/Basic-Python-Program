# Program to Use List Comprehension with Condition:

numbers = [1, 2, 3, 4, 5]
even_numbers = [x for x in numbers if x % 2 == 0]
print(even_numbers) # Outputs: [2, 4]
print("56.This code is written by Raghavv Gupta ERP- 0221BCA032")