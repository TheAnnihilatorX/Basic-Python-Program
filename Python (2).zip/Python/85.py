# WAP for importing specific function

from math_utils import add 
result = add(5, 6) 
print(result) 
print("85. This code is written by Raghavv Gupta ERP- 0221BCA032")
