# Python program to demonstrate formatted or F string

name = "Raghavv"
age = 20
print(f"Name: {name} , Age: {age}")
print("21.THIS PROGRAM IS WRITTEN BY Raghavv Gupta ERP :- 0221BCA032")