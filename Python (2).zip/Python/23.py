#math module
import math

num = 16
print(f"Square root of {num} is {math.sqrt(num)}")
print(f"Factorial of {num} is {math.factorial(num)}")
print(f"Logarithm of {num} is {math.log2(num)}")

print("23.THIS PROGRAM IS WRITTEN BY Raghavv GUpta ERP :- 0221BCA032")