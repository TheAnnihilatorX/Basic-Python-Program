# Program to Create and Modify a Dictionary:

my_dict = {'name': 'Alice', 'age': 25}
my_dict['age'] = 26
my_dict['city'] = 'New York'
print(my_dict) # Outputs: {'name': 'Alice', 'age': 26, 'city': 'New York'}
print("68.This code is written by Raghavv Gupta ERP- 0221BCA032")