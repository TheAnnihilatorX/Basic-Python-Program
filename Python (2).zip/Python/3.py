#using keywords in python
#if-else conditional statements
_variable=7
if _variable > 5:
    print("variable is greater than 5")
else:
    print("variable is 5 or less")
#while loop
count=0
while count<5:
    print(count)
    count+=1

# for loop
for i in range(5):
    print(i);
print("THIS PROGRAM IS WRITTEN BY JAGRIT AHUJA ERP :- 0221BCA142")