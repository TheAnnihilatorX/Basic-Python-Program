# WAP to demonstrate aliasing module and functions

import math_utils as mu 
result = mu.add(5, 45) 
print(result)
print("87. This code is written by Raghavv Gupta ERP- 0221BCA032")
