# Program to Use Lambda Expressions with map():

numbers = [1, 2, 3, 4]
squared = list(map(lambda x: x**2, numbers))
print(squared) # Outputs: [1, 4, 9, 16]
print("58.This code is written by Raghavv Gupta ERP- 0221BCA032")