# Python program to demonstrate print statement with multiple statements

age = int(input("Enter your age: "))
has_license = True

if age >= 18 and has_license:
    print("You can drive.")
else:
    print("You cannot drive.")
    print("THIS PROGRAM IS WRITTEN BY Raghavv Gupta ERP :- 0221BCA032")