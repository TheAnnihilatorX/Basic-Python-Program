#WAP to create add function that takes 2 parameters 

def add(a,b):
    return a+b
result= add(10,20)
print(result)
print("71.This code is written by Raghavv Gupta ERP- 0221BCA032")