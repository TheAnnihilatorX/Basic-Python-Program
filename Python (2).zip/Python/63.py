# Program to Use range() with Start and Stop:

for i in range(2, 6):
 print(i) # Outputs: 2, 3, 4, 5
print("63.This code is written by Raghavv Gupta ERP- 0221BCA032")