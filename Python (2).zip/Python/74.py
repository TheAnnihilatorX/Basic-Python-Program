#WAP to return list through function

def get_squares(numbers):
    squares = [n**2 for n in numbers]
    return squares
nums = [1,2,3,4]
squares_list = get_squares(nums)
print(squares_list)
print("74.This code is written by Raghavv Gupta ERP- 0221BCA032")