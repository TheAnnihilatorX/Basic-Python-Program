# Example of a while loop in Python
count = 0
while count < 5:
    print("Count is:", count)
    count += 1  

    print("30.THIS PROGRAM IS WRITTEN BY Raghavv Gupta ERP :- 0221BCA032")