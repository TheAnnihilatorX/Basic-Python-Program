# WAP to Using a Module
import math_utils
def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

result = math_utils.add(5, 3)
print(result)  # Output: 8
print("84. This code is written by Raghavv Gupta ERP- 0221BCA032")