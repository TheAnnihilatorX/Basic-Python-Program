# Program to Slice and Access List Elements:

my_list = ['a', 'b', 'c', 'd', 'e']
first_element = my_list[0]
last_element = my_list[-1]
sub_list = my_list[1:4]
print("First element:", first_element) # Outputs: a
print("Last element:", last_element) # Outputs: e
print("Sliced list:", sub_list) # Outputs: ['b', 'c', 'd']
print("48.This code is written by Raghavv Gupta ERP- 0221BCA032")