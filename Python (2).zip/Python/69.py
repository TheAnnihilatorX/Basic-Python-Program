# Program to Access and Remove Dictionary Elements:

my_dict = {'name': 'Bob', 'age': 30, 'job': 'Engineer'}
name = my_dict.get('name')
my_dict.pop('job')
print(name) # Outputs: Bob
print(my_dict) # Outputs: {'name': 'Bob', 'age': 30}
print("69.This code is written by Raghavv Gupta ERP- 0221BCA032")
